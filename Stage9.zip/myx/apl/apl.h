%{
#include<stdio.h>
#include<stdlib.h>
#include "apl.h"
extern FILE *yyin;
%}
%union
{
	struct tree *n;
	struct ArgStruct *arg;
}
%token NUM OPER1 OPER2 ID INT STR STRING MAIN BEGN END DECL ENDDECL ASG READ PRINT RELOP LOGOP NEGOP IF ELSE THEN ENDIF WHILE DO ENDWHILE RETURN SYSCREA SYSOPEN SYSWRIT SYSSEEK SYSREAD SYSCLOS SYSDELE SYSFORK SYSEXEC SYSEXIT SYSGPID SYSGPPID SYSWAIT SYSSIGNAL BREAK CONTINUE BREAKPOINT
%type<n> stmtlist param stmt retstmt expr ids fID Body SysCall NUM STRING OPER1 OPER2 ID ASG READ PRINT RELOP LOGOP NEGOP IF WHILE RETURN SYSCREA SYSOPEN SYSWRIT SYSSEEK SYSREAD SYSCLOS SYSDELE SYSFORK SYSEXEC SYSEXIT SYSGPID SYSGPPID SYSWAIT SYSSIGNAL ifpad whilepad BREAK CONTINUE BREAKPOINT
%type<arg> ArgId ArgIdList ArgDecl ArgList fArgList
%left LOGOP
%left RELOP  
%left OPER1		// + and -
%left OPER2		// * , / and %
%right NEGOP
%left UMIN		// unary minus

%%
prog:		GDefblock FDefList Mainblock		{}
		;
		
GDefblock:						{
							fflush(fp);
							main_pos = ftell(fp);
							out_linecount++;
							fprintf(fp,"JMP 00000\n");
							}
	
		|DECL GDefList ENDDECL			{
							fflush(fp);
							main_pos = ftell(fp);
							out_linecount++;
							fprintf(fp,"JMP 00000\n");
							}
		;
		
GDefList:	GDecl					{}

		| GDefList GDecl			{}
		;
		
GDecl:		Type GIdList ';'			{}
		;
Type:		INT					{m=0;
							}
		|STR					{m=3;
							}
		;		
GIdList:	 GId					{}

		|GIdList ',' GId			{}
		;
		
GId:		ID					{install($1,m,1);
							}
		|ID '[' NUM ']'				{install($1,m,$3->value);
							}
		|ID '(' ArgList ')'			{finstall($1,m,$3);
							/*while($3!=NULL)
							{
								printf(" %s-%d\n",$3->name,$3->type);
								$3=$3->next;
							}*/
							}
		
		;
FDefList:						{}
		
		|FDefList Fdef				{}
		;
		
Fdef:		RType fID '(' fArgList ')' '{' Body '}'	{/*struct Lsymbol *temp=Lroot;
									while(temp!=NULL)
									{
										printf(" %s-%d-%d\n",temp->name,temp->type,temp->bind);
										temp=temp->next;
									}*/
									codegen($7);
									Lroot=NULL;
									funcid=NULL;										
									}
		;
RType:		INT					{m3=0;
							}
		|STR					{m3=3;
							}
		;
		
fID:		ID					{memcount=1;
							$1->type=m3;
							funcid=$1;
							$$=$1;
							}
		;

fArgList:	ArgList					{fdefcheck(funcid,$1,m3);
							arglistinstall(funcid);
							}
		;
				
ArgList:						{$$=NULL;
							}	
		|ArgDecl 				{$$=$1;							
							}
		|ArgList ';' ArgDecl			{$$=makeargtree($1,$3);							
							}
		;
		
ArgDecl:	ArgType ArgIdList			{$$=$2;}
		;

ArgType:	INT					{m2=0;
							}
		|STR					{m2=3;
							}
		;
		
ArgIdList:	 ArgId					{$$=$1;
							}
		|ArgIdList ',' ArgId			{$$=makeargtree($1,$3);
							}
		;
		
ArgId:		ID					{
							$$=makearg($1->name,m2,0);
							}
		|'&' ID					{$$=makearg($2->name,m2,1);
							}
		;		
				
Mainblock:	 INT fMAIN '(' ')' '{' Body '}'		{codegen($6);
							out_linecount+=2;
							fprintf(fp, "MOV R0, 10\nPUSH R0\n");
							out_linecount++;
							fprintf(fp, "INT 7\n");;
							fclose(fp);						
				 			//printf("%d Lines Compiled\n",linecount);
							return(0);
							}
		;

fMAIN:		MAIN					{m3=0;
							memcount=1;
							funcid=NULL;
							fflush(fp);
							temp_pos = ftell(fp);
							fseek(fp,main_pos,SEEK_SET);
							fprintf(fp,"JMP %05d",out_linecount*2);
							fseek(fp,temp_pos,SEEK_SET);
							out_linecount+=2; fprintf(fp,"PUSH BP\nMOV BP,SP\n"); 
							}
		;

LDecl:		Type LIdList ';'			{}
		;
		
LIdList:	 LId					{}

		|LIdList ',' LId			{}
		;
		
LId:		ID					{Linstall($1,m,1);
							}
		;

Body:		stmtlist retstmt			{$$=nontermcreate("Body",$1,$2);			
							}
		|retstmt				{$$=nontermcreate("Body",$1,NULL);			
							}
		;
retstmt:	RETURN expr ';'				{$$=maketree($1,$2,NULL,NULL);
							}
		;
 	
stmtlist:	stmtlist stmt 				{$$=nontermcreate("stmtlist",$1,$2);
							}
		|stmt					{$$=$1;
							}
		;
		
stmt:		ids ASG expr ';'	 		{$$=maketree($2,$1,$3,NULL);
							}
		|READ '(' ids ')' ';'			{$$=maketree($1,$3,NULL,NULL);
							}
		|PRINT '(' expr ')' ';'			{$$=maketree($1,$3,NULL,NULL);
							}
		
		|ifpad expr THEN stmtlist ENDIF ';'				{$$=maketree($1,$2,$4,NULL);flag_decl--;
										}
		|ifpad expr THEN stmtlist ELSE stmtlist ENDIF ';'		{$$=maketree($1,$2,$4,$6);flag_decl--;
										}
		|whilepad expr DO stmtlist ENDWHILE ';'				{$$=maketree($1,$2,$4,NULL);flag_decl--;flag_break=0;
										}
		|LDecl					{$$=NULL;
							}
		|SYSEXIT '(' ')' ';'			{$$=$1;		
							}
		|BREAK ';'				{if(flag_break==0)
							{
								printf("\n%d: break or continue should be used inside while!!\n",linecount);
								exit(0);								
							}
							$$=$1;
							}
		|CONTINUE ';'				{if(flag_break==0)
							{
								printf("\n%d: break or continue should be used inside while!!\n",linecount);
								exit(0);								
							}
							$$=$1;
							}
		|BREAKPOINT ';'				{$$=$1;		
							}					
		;

ifpad:		IF					{
								flag_decl++;
								$$=$1;
							}
		;

whilepad:	WHILE					{
								flag_decl++;
								flag_break=1;
								$$=$1;
							}
		;
				
expr:		expr OPER1 expr				{$$=maketree($2,$1,$3,NULL);
							}
		|expr OPER2 expr			{$$=maketree($2,$1,$3,NULL);
							}
		|expr RELOP expr 			{$$=maketree($2,$1,$3,NULL);
							}
		|expr LOGOP expr			{$$=maketree($2,$1,$3,NULL);
							}
		|NEGOP expr				{$$=maketree($1,$2,NULL,NULL);
							}
		|'('expr')'				{$$=$2;
							}
		|OPER1 expr	%prec UMIN		{$$=maketree($1,$2,NULL,NULL);
							}
		|SysCall				{$$=$1;
							}
		|NUM					{$$=$1;
							}
		|STRING					{$$=$1;
							}
		|ids					{$$=$1;
							}
		;
			
ids:		ID					{$$=maketree($1,NULL,NULL,NULL);
							}
		|ID '[' expr ']'			{$$=maketree($1,$3,NULL,NULL);
							}
		|ID'(' param ')'			{$$=functioncall($1,$3);
							/*while($3!=NULL)
							{
								printf(" %s - %d\n",$3->name,$3->type);
								$3=$3->ptr3;
							}*/
							}
		;
		
param:							{$$=NULL;
							}
		|expr					{$$=$1;
							}	
		|param ',' expr				{$$=makeparam($1,$3);
							}
		;
		
SysCall:	SYSCREA '(' param ')'			{$$=syscheck($1,$3,1);
							}
		|SYSOPEN '(' param ')'			{$$=syscheck($1,$3,1);
							}
		|SYSWRIT '(' param ')'			{$$=syscheck($1,$3,5);
							}
		|SYSSEEK '(' param ')'			{$$=syscheck($1,$3,3);
							}
		|SYSREAD '(' param ')'			{$$=syscheck($1,$3,2);
							}
		|SYSCLOS '(' param ')'			{$$=syscheck($1,$3,4);
							}
		|SYSDELE '(' param ')'			{$$=syscheck($1,$3,1);
							}
		|SYSFORK '(' ')'			{$$=$1;
							}
		|SYSEXEC '(' param ')'			{$$=syscheck($1,$3,1);
							}	
		|SYSGPID '(' ')'			{$$=$1;
							}	
		|SYSGPPID '(' ')'			{$$=$1;
							}
		|SYSWAIT '(' param ')'			{$$=syscheck($1,$3,4);
							}	
		|SYSSIGNAL '(' ')'			{$$=$1;
							}	
		;
		
%%
int main (int argc, char **argv)
{	
	FILE *input_fp;
	char filename[200],ch;
	strcpy(filename,argv[1]);	
	if(argc < 2)
	{
		printf("Specify an input filename\n");
		return 0;
	}
	expandpath(filename);
	input_fp = fopen(filename,"r");
	if(!input_fp)
	{
		printf("Invalid input file\n");
		return 0;
	}
	yyin = input_fp;
	changeext(filename);
	fp=fopen(".temp","wb");
	out_linecount++; fprintf(fp,"START\n");
	out_linecount++; fprintf(fp,"MOV SP, 1535\n");
	out_linecount++; fprintf(fp,"MOV BP, 1535\n");
	yyparse();
	fclose(input_fp);
	input_fp = fopen(".temp","r");
	if(!input_fp)
	{
		printf("Writing compiled code to file failed\n");
		return 0;
	}
	fp = fopen(filename,"wb");
	if(!fp)
	{
		fclose(input_fp);
		printf("Writing compiled code to file failed\n");
		return 0;
	}
	while( ( ch = fgetc(input_fp) ) != EOF )
		fputc(ch, fp);
	fclose(input_fp);
	fclose(fp);	
	return 0;	
}
int yyerror (char *msg) 
{
	return fprintf (stderr, "%d: %s\n",linecount,msg);
}
